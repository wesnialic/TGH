const horaires = [
  "06:20", "06:53", "07:01", "07:21", "07:29",
  "08:01", "08:30", "09:12", "10:12", "10:43",
  "11:11", "11:39", "12:09", "12:30", "13:13"
];

function updateClock() {
  const now = new Date();
  document.getElementById("clock").textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function afficherHoraires() {
  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();

  let prochainBus = null;
  const scheduleContainer = document.getElementById("schedule");
  scheduleContainer.innerHTML = "";

  horaires.forEach(horaire => {
    const [h, m] = horaire.split(":").map(Number);
    const totalMinutes = h * 60 + m;

    const box = document.createElement("div");
    box.classList.add("time-box");
    box.textContent = horaire;

    if (totalMinutes < currentTime) {
      box.classList.add("passed");
    } else if (!prochainBus) {
      box.classList.add("next");
      prochainBus = horaire;
    }

    scheduleContainer.appendChild(box);
  });

  const nextBusDiv = document.getElementById("next-bus");
  if (prochainBus) {
    nextBusDiv.textContent = `Prochain bus à ${prochainBus}`;
  } else {
    nextBusDiv.textContent = "Plus de bus aujourd'hui";
  }
}

function init() {
  updateClock();
  afficherHoraires();
  setInterval(() => {
    updateClock();
    afficherHoraires();
  }, 60000);
}

window.onload = init;
